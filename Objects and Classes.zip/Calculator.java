package oops;

public class Calculator {
	static double powerInt(int num1,int num2) {
		return Math.pow(num1, num2);
	}
	static double powerDouble(double num1,int num2) {
		return Math.pow(num1, num2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Calculator c=new Calculator();
        System.out.println(c.powerInt(2, 2));
        System.out.println(c.powerDouble(3,3));
        
	}

}
