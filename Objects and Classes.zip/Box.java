package oops;
public class Box {
    private int l;
    private int w;
    private int h;
void Box(int l,int w,int h){
        this.l=l;
        this.w=w;
        this.h=h;
    }
void display(){
        System.out.println(l*w*h);
    }
public static void main(String args[]){
    Box b=new Box();
    b.Box(10, 10, 10);
    b.display();
}
}

