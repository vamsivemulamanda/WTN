package form.wipro.languagebasics;

public class W32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int d=Integer.parseInt(args[2]);
		int e=Integer.parseInt(args[3]);
		int f=Integer.parseInt(args[4]);
		int g=Integer.parseInt(args[5]);
		int[] c= {a,b,d};
		int [] x= {e,f,g};
		int low=c[0];
		int high=(c.length)-1;
		int low_1=x[0];
		int high_1=(x.length)-1;
		int mid=(low+high)/2;
		int mid_1=(low_1+high_1)/2;
		for(int i=0;i<c.length;i++) {
			if(i==mid) {
				int z=c[i];
				int[] p= {z};
			}
		}
		for(int j=0;j<x.length;j++) {
			if(j==mid_1) {
				int y=x[j];
				int[] p= {y};
				
			}
		}
		}
		
	}


