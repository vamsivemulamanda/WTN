package form.wipro.languagebasics;

public class W30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int d=Integer.parseInt(args[2]);
		int e=Integer.parseInt(args[3]);
		int[] c= {a,b,d,e};
		for(int i=0;i<c.length;i++) {
			if(c[i]==10) {
				c[i]=0;			}
		}
		for(int i=0;i<c.length;i++) {
			if(c[i]!=0) {
				System.out.print(c[i]+ " ");
			}
		}
		for(int i=0;i<c.length;i++) {
			if(c[i]==0) {
				System.out.print(c[i]+ " ");
			}
		}

}
}

