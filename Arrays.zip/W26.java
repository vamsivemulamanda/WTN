package form.wipro.languagebasics;

public class W26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int d=Integer.parseInt(args[2]);
		int e=Integer.parseInt(args[3]);
		int[] c= {a,b,d,e};
		int min=c[0];
		int max=0;
		for(int i=1;i<c.length;i++) {
			if(c[i]<min) {
				min=c[i];
			}
		}
		for(int j=0;j<c.length;j++) {
			if(c[j]>max) {
				max=c[j];
			}
		}
	   int min_1=0;
	   int max_1=0;
	   for(int i=0;i<c.length;i++) {
		   if(c[i]>min && c[i]<max) {
			   if(max_1<c[i]) {
				   max_1=c[i];
			   }
			   
		   }
	   }
	   for(int i=(c.length)-1;i>0;i--) {
		   if(c[i]<max && c[i]>min) {
			  min_1=c[i];
		   }
	   }
	   System.out.println(min);
	   System.out.println(min_1);
	   System.out.println(max);
	   System.out.println(max_1);
	}

}
