package form.wipro.languagebasics;

public class W22 {

	public static void main(String[] args) {
		int d []= {1,2,3,4};
		int sum=0;
		for(int i=0;i<d.length;i++) {
			sum=sum+d[i];
		}
		int avg=sum/d.length;

	    System.out.println(sum);
	    System.out.println(avg);

}
}
