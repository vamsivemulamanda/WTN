package form.wipro.languagebasics;

public class W31_0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int d=Integer.parseInt(args[2]);
		int e=Integer.parseInt(args[3]);
		int[] c= {a,b,d,e};
		for(int i=0;i<c.length;i++) {
			if(c[i]%2==0) {
				System.out.print(c[i]+ " ");
			}
		}
		for(int i=0;i<c.length;i++) {
			if(c[i]%2!=0) {
				System.out.print(c[i]+ " ");
			}
		}

	}

}
