package form.wipro.languagebasics;

public class W24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int d=Integer.parseInt(args[2]);
		int e=Integer.parseInt(args[3]);
		int z=Integer.parseInt(args[4]);
		int[] c= {a,b,d,e};
		int x=0;
		for(int i=0;i<c.length;i++) {
			x=0;
			if(c[i]==z) {
				x=x+1;
				if(x>0) {
					System.out.println(i);
				}
		}

	}

}
}
