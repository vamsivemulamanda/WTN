package form.wipro.languagebasics;

public class W29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int d=Integer.parseInt(args[2]);
		int e=Integer.parseInt(args[3]);
		int f=Integer.parseInt(args[4]);
		int g=Integer.parseInt(args[5]);
		int h=Integer.parseInt(args[6]);
		int[] c= {a,b,d,e,f,g,h};
		int k=0;
		int y=0;
		int sum=0;
		int rev=0;
		for(int i=0;i<c.length;i++) {
			if(c[i]==6) {
				k=i;
			}
			else if(c[i]==7){
				y=i;
			}
		}
			if(k<y) {
				for(int i=0;i<c.length;i++) {
					if(i<k || i>y) {
					sum=sum+c[i];	
					}
					
				
				}
				System.out.println(sum);
			}
			else {
				for(int i=0;i<c.length;i++) {
					rev=rev+c[i];
					
				}
				System.out.println(rev);
			}
				
		}

	}


