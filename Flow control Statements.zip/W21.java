package form.wipro.languagebasics;

public class W21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int r=0;
		while(a!=0) {
			int d=a%10;
			r=r*10+d;
			a=a/10;
		}
		if(a==r) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not palindrome");
		}

	}

}
