package form.wipro.languagebasics;

public class W9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
