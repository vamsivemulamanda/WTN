package form.wipro.languagebasics;

public class W14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       for(int i=1;i<=10;i++) {
    	   System.out.print(i);
    	   for(int j=i;j<=i;j++) {
    		   System.out.print(" ");
    	   }
       }
	}

}
