package form.wipro.languagebasics;

public class W7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String []a= {args[0],args[1],args[2]};
		if(a.length>0) {
			for(int i=0;i<a.length;i++) {
				System.out.print(a[i]);
				for(int j=i;j<(a.length)-1;j++) {
					System.out.print(",");
					break;
				}
			}
		}
			else {
				System.out.println("No values");
			}
		}

}
