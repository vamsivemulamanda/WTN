package form.wipro.languagebasics;

public class W10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String gender=args[0];
	int a=Integer.parseInt(args[1]);
	if(gender=="Female") {
		if(a>=1 && a<=58) {
			System.out.println("The percentage of intrest is"+" 8.2%");
		}
		else if(a>=59 && a<=100){
			System.out.println("The percentage of intrest is"+" 9.2%");
		}
	}
	else {
		if(a>=1 && a<=58) {
			System.out.println("The percentage of intrest is"+" 9.4%");
		}
		else if(a>=59 && a<=100){
			System.out.println("The percentage of intrest is"+" 10.5%");
		}
	}

	}

}
