package form.wipro.languagebasics;

public class W8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a=args[0];
		
	}
}
