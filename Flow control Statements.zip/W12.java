package form.wipro.languagebasics;

public class W12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String a=args[0];
        if(a=="R") {
        	System.out.println("Red");
        }
        else if(a=="B") {
        	System.out.println("Blue");
        }
        else if(a=="G") {
        	System.out.println("Green");
        }
        else if(a=="Y") {
        	System.out.println("Yellow");
        }
        else if(a=="O") {
        	System.out.println("Orange");
        }
        else if(a=="W") {
        	System.out.println("White");
        }
	}

}
