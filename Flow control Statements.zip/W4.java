package form.wipro.languagebasics;

public class W4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a=Integer.parseInt(args[0]);
        if(a<0) {
        	System.out.println("Negative");
        }
        else if(a>0){
        	System.out.println("Positive");
        }
        else {
        	System.out.println("Zero");
        }
	}

}
