package form.wipro.languagebasics;

public class W19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int i=0;
		while(i!=a) {
			for(int j=0;j<=i;j++) {
				System.out.print("* ");
			}
			System.out.println();
			i=i+1;
		}

	}

}
