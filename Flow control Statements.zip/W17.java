package form.wipro.languagebasics;

public class W17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0;
		for(int j=10;j<=99;j++) {
			c=0;
			for(int i=1;i<=j;i++) {
				if(j%i==0) {
					c=c+1;
				}
			}
			if(c==2) {
				System.out.println(j);
			}
		}
	}
}
