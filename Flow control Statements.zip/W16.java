package form.wipro.languagebasics;

public class W16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b=Integer.parseInt(args[0]);
		int c=0;
		for(int i=1;i<=b;i++) {
			if(b==1) {
				System.out.println("Neither Prime Nor Composite");
			}
			else {
			     if(b%i==0) {
			    	 c=c+1;
				}
			}
		}
		if(c>2) {
			System.out.println("Not Prime");
		}
		else {
			System.out.println("Prime");
		}

	}

}
