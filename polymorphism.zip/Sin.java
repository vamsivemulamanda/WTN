package oops;
class Fruit{
	private String name;
	private String Taste;
	private int size;
	void eat(String name,String Taste) {
		this.name=name;
		this.Taste=Taste;
		System.out.println(name+ " "+Taste);
	}
}
class Apple extends Fruit{
	void eat(String Taste) {
	   System.out.println(Taste);
	}
}
class Orange extends Fruit{
	void eat(String Taste) {
		System.out.println(Taste);
	}
}

public class Sin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fruit f=new Fruit();
		f.eat("Apple", "Sweet");
		Apple a=new Apple();
		a.eat("sweet");
		f.eat("orange", "sour");
		Orange o=new Orange();
		o.eat("sour");
		

	}

}
