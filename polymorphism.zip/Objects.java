package oops;
class shape{
	void draw() {
		System.out.println("Drawing Shape");
	}
	void erase() {
		System.out.println("Erasing Shape");
	}
}
class Circle extends shape{
	void draw() {
		System.out.println("Circle drawing shape");
	}
	void erase() {
		System.out.println("Circle erasing shape");
	}
}
class Triangle extends shape{
	void draw() {
		System.out.println("Triangle drawing shape");
	}
	void erase() {
		System.out.println("Triangle Erasing Shape");
	}
}
class Square extends shape{
	void draw() {
		System.out.println("Square drawing shape");
	}
	void erase() {
		System.out.println("Square erasing shape");
	}
}

public class Objects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		shape c=new Circle();
		shape T=new Triangle();
		shape S=new Square();
		c.draw();
		c.erase();
		T.draw();
		T.erase();
		S.draw();
		S.erase();

	}

}
