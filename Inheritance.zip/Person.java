package oops;

class Person {
	private String name;
	void setPerson(String name) {
		this.name=name;
	}
	void getPerson() {
		System.out.println(name);
	}
	

}
