package oops;

class Employee extends Person {
 private double annualsalary;
 private int year;
 private String NationalInsuranceNumber;
 void setEmployee(double annualsalary,int year,String NationalInsuranceNumber) {
	 this.annualsalary=annualsalary;
	 this.year=year;
	 this.NationalInsuranceNumber=NationalInsuranceNumber;
 }
 void getEmployee() {
	 System.out.println(annualsalary);
	 System.out.println(year);
	 System.out.println(NationalInsuranceNumber);
 }
}
