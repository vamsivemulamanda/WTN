package oops;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Person p=new Person();
       Employee e=new Employee();
       p.setPerson("vamsi");
       e.setEmployee(1000000,2020,"ASDFGH");
       p.getPerson();
       e.getEmployee();
       
	}

}
