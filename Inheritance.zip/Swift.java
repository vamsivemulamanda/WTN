package oops;
class Animal{
	void eat() {
		System.out.println("eat");
	}
	void sleep() {
		System.out.println("sleep");
	}
}
class Bird extends Animal{
	void eat() {
		System.out.println("Bird eat");
	}
	void sleep() {
		System.out.println("Bird sleep");
	}
	void fly() {
		System.out.println("Bird fly");
	}
}

public class Swift {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a=new Animal();
		Bird b=new Bird();
		a.sleep();
		a.eat();
		b.eat();
		b.sleep();
		b.fly();
		

	}

}
