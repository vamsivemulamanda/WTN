package Music;

public interface playable {
public void play();
}
