package Music.Wind;
import Music.*;
public class saxophone implements playable {
public void play() {
	System.out.println("saxophone music");
}
}
