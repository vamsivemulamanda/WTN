package Live;
import Music.String.*;
import Music.Wind.*;
public class Musician {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        veena v=new veena();
        saxophone s=new saxophone();
        v.play();
        s.play();
    	}

}
