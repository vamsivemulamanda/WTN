package Music.String;
import Music.*;
public class veena implements playable {
public void play() {
	System.out.println("Veena Music");
}
}
